from sqlalchemy import Column, String, Integer, DateTime, Float, Boolean, JSON, Text
from sqlalchemy.ext.declarative import declarative_base
from datetime import datetime

Base = declarative_base()


class ServiceHealth(Base):
    """Метрики здоровья сервисов"""
    __tablename__ = "service_health"
    
    id = Column(Integer, primary_key=True, index=True)
    service_name = Column(String(255), index=True, nullable=False)
    service_type = Column(String(50), nullable=False)  # vercel, heroku, api_key, database
    status = Column(String(20), nullable=False)  # healthy, degraded, down
    response_time = Column(Float, nullable=True)  # в секундах
    last_checked = Column(DateTime, default=datetime.utcnow, nullable=False, index=True)
    error_message = Column(Text, nullable=True)
    metadata = Column(JSON, nullable=True)
    
    def __repr__(self):
        return f"<ServiceHealth(service={self.service_name}, status={self.status})>"


class UserActivity(Base):
    """Активность пользователей"""
    __tablename__ = "user_activity"
    
    id = Column(Integer, primary_key=True, index=True)
    timestamp = Column(DateTime, default=datetime.utcnow, nullable=False, index=True)
    active_users = Column(Integer, default=0)
    total_requests = Column(Integer, default=0)
    avg_response_time = Column(Float, default=0.0)
    endpoint = Column(String(255), nullable=True)
    
    def __repr__(self):
        return f"<UserActivity(timestamp={self.timestamp}, users={self.active_users})>"


class SystemAlert(Base):
    """Системные алерты"""
    __tablename__ = "system_alerts"
    
    id = Column(Integer, primary_key=True, index=True)
    severity = Column(String(20), nullable=False)  # info, warning, critical
    service_name = Column(String(255), nullable=False, index=True)
    message = Column(Text, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False, index=True)
    resolved = Column(Boolean, default=False, nullable=False, index=True)
    resolved_at = Column(DateTime, nullable=True)
    resolved_by = Column(String(255), nullable=True)
    
    def __repr__(self):
        return f"<SystemAlert(service={self.service_name}, severity={self.severity}, resolved={self.resolved})>"


class APIUsageMetrics(Base):
    """Метрики использования API"""
    __tablename__ = "api_usage_metrics"
    
    id = Column(Integer, primary_key=True, index=True)
    timestamp = Column(DateTime, default=datetime.utcnow, nullable=False, index=True)
    api_name = Column(String(100), nullable=False, index=True)  # openai, anthropic, etc.
    requests_count = Column(Integer, default=0)
    tokens_used = Column(Integer, default=0)
    cost_usd = Column(Float, default=0.0)
    errors_count = Column(Integer, default=0)
    
    def __repr__(self):
        return f"<APIUsageMetrics(api={self.api_name}, requests={self.requests_count})>"
