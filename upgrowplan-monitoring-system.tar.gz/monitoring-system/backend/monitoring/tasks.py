from celery import Celery
from datetime import datetime
import logging
from .config import get_config
from .database import get_db_session
from .models import ServiceHealth, SystemAlert, UserActivity
from .health_checkers import check_all_services
from .alerting import AlertManager

logger = logging.getLogger(__name__)

# Инициализация Celery
config = get_config()
celery_app = Celery(
    'monitoring',
    broker=config.REDIS_URL,
    backend=config.REDIS_URL
)

# Конфигурация Celery
celery_app.conf.update(
    task_serializer='json',
    accept_content=['json'],
    result_serializer='json',
    timezone='UTC',
    enable_utc=True,
)


@celery_app.task(name='monitoring.check_all_services')
def check_all_services_task():
    """
    Периодическая проверка всех сервисов
    Запускается каждые 5 минут
    """
    import asyncio
    
    try:
        logger.info("Starting service health checks...")
        
        # Запускаем async функцию
        results = asyncio.run(check_all_services(config))
        
        alert_manager = AlertManager()
        
        # Сохраняем результаты в БД
        with get_db_session() as db:
            for result in results:
                service_name = result["service_name"]
                
                # Получаем предыдущий статус
                previous = db.query(ServiceHealth).filter(
                    ServiceHealth.service_name == service_name
                ).order_by(ServiceHealth.last_checked.desc()).first()
                
                previous_status = previous.status if previous else None
                current_status = result["status"]
                
                # Создаем запись в БД
                health_record = ServiceHealth(
                    service_name=service_name,
                    service_type=result["service_type"],
                    status=current_status,
                    response_time=result.get("response_time"),
                    error_message=result.get("error_message"),
                    metadata=result.get("metadata"),
                    last_checked=datetime.utcnow()
                )
                db.add(health_record)
                
                # Проверяем, нужно ли создать алерт
                if alert_manager.should_send_alert(service_name, current_status, previous_status):
                    severity = alert_manager.get_alert_severity(current_status)
                    
                    # Формируем сообщение
                    if current_status == "healthy" and previous_status in ["degraded", "down"]:
                        message = f"Service recovered: {service_name} is now healthy"
                    elif current_status == "down":
                        error_msg = result.get("error_message", "Unknown error")
                        message = f"Service is down: {error_msg}"
                    else:  # degraded
                        error_msg = result.get("error_message", "Performance issues detected")
                        message = f"Service degraded: {error_msg}"
                    
                    alert = SystemAlert(
                        severity=severity,
                        service_name=service_name,
                        message=message,
                        created_at=datetime.utcnow()
                    )
                    db.add(alert)
                    db.commit()
                    
                    # Отправляем уведомление
                    asyncio.run(alert_manager.send_alert(alert))
            
            db.commit()
        
        logger.info(f"Health checks completed: {len(results)} services checked")
        return {"status": "success", "services_checked": len(results)}
    
    except Exception as e:
        logger.error(f"Error in check_all_services_task: {e}")
        return {"status": "error", "message": str(e)}


@celery_app.task(name='monitoring.collect_user_activity')
def collect_user_activity_task():
    """
    Сбор метрик активности пользователей
    Запускается каждую минуту
    """
    try:
        logger.info("Collecting user activity metrics...")
        
        # Здесь нужно будет подключить твою аналитику
        # Например, запрос к твоему API для получения текущих метрик
        
        # Заглушка для примера
        activity_data = {
            "active_users": 0,  # Получить из твоей аналитики
            "total_requests": 0,  # Получить из твоей аналитики
            "avg_response_time": 0.0  # Получить из твоей аналитики
        }
        
        # Сохраняем в БД
        with get_db_session() as db:
            activity = UserActivity(
                timestamp=datetime.utcnow(),
                active_users=activity_data["active_users"],
                total_requests=activity_data["total_requests"],
                avg_response_time=activity_data["avg_response_time"]
            )
            db.add(activity)
            db.commit()
        
        logger.info("User activity metrics collected")
        return {"status": "success"}
    
    except Exception as e:
        logger.error(f"Error in collect_user_activity_task: {e}")
        return {"status": "error", "message": str(e)}


@celery_app.task(name='monitoring.cleanup_old_data')
def cleanup_old_data_task():
    """
    Очистка старых данных из БД
    Запускается раз в день
    """
    try:
        from datetime import timedelta
        
        logger.info("Cleaning up old data...")
        
        with get_db_session() as db:
            # Удаляем метрики старше 30 дней
            cutoff_date = datetime.utcnow() - timedelta(days=30)
            
            deleted_health = db.query(ServiceHealth).filter(
                ServiceHealth.last_checked < cutoff_date
            ).delete()
            
            deleted_activity = db.query(UserActivity).filter(
                UserActivity.timestamp < cutoff_date
            ).delete()
            
            # Удаляем resolved алерты старше 7 дней
            alert_cutoff = datetime.utcnow() - timedelta(days=7)
            deleted_alerts = db.query(SystemAlert).filter(
                SystemAlert.resolved == True,
                SystemAlert.resolved_at < alert_cutoff
            ).delete()
            
            db.commit()
        
        logger.info(f"Cleanup completed: {deleted_health} health records, "
                   f"{deleted_activity} activity records, "
                   f"{deleted_alerts} alerts deleted")
        
        return {
            "status": "success",
            "deleted": {
                "health_records": deleted_health,
                "activity_records": deleted_activity,
                "alerts": deleted_alerts
            }
        }
    
    except Exception as e:
        logger.error(f"Error in cleanup_old_data_task: {e}")
        return {"status": "error", "message": str(e)}


# Периодические задачи
@celery_app.on_after_configure.connect
def setup_periodic_tasks(sender, **kwargs):
    """Настройка расписания для периодических задач"""
    
    # Проверка сервисов каждые 5 минут
    sender.add_periodic_task(
        300.0,  # 5 минут
        check_all_services_task.s(),
        name='check-all-services-5min'
    )
    
    # Сбор активности пользователей каждую минуту
    sender.add_periodic_task(
        60.0,  # 1 минута
        collect_user_activity_task.s(),
        name='collect-user-activity-1min'
    )
    
    # Очистка старых данных раз в день в 3:00 AM
    sender.add_periodic_task(
        crontab(hour=3, minute=0),
        cleanup_old_data_task.s(),
        name='cleanup-old-data-daily'
    )
